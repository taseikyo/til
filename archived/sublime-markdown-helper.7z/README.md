# sublime-markdown-helper

A Sublime Text 3 plugin that can help write markdown faster (maybe :0)

I am new to the st3 plugin, and my motivation is to focus on text rather than markdown syntax. So my task is to write the notes, and the rest is done by the plugin, converting plain text to markdown documents.

## preview

<center>
	
![preview](images/preview.gif)
</center>


## how to use

Go to Preferences -> Browse Packages, and then either download and unzip this plugin into that directory, or:

git clone https://github.com/taseikyo/sublime-markdown-helper.git "sublime-markdown-helper"

### shortcuts

| Keyboard shortcut |	Description  |
|-------------------|----------------|
|ctrl + 1-3         |h1 - h3         |
|ctrl + 4	        |ul              |
|ctrl + 5			|ol 			 |
|ctrl + 6			|code (block codes)|
|ctrl + 7			|latex formula (block)|

**Note: Remember to select the entire line before you press the shortcuts.**

## License

Copyright (c) 2020 Lewis Tian. Licensed under the MIT license.