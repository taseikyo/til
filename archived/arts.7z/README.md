> @Date    : 2020-09-02 20:41:56
>
> @Author  : Lewis Tian (taseikyo@gmail.com)
>
> @Link    : github.com/taseikyo

# ARTS

原本的 [arts](https://github.com/taseikyo/arts) 已经被删除，而内容被保存为本目录下的 `arts.7z`，因为有许多东西跟 til 这个项目很像，所以干脆合并（删库是某人的传统艺能了），下面是原本 README 中对 arts 的介绍，这里也贴出来，可能后面会继续以另一种形式组织 **arts**，比如把 til 做一个每周总结，然后按照下面的分类，组织一波，当然也有可能不会重启了。

## 🤔 What is *arts*？
The idea of *arts* was proposed by [Hao Chen](https://github.com/haoel), including algorithm, review, tip & share.
- algorithm: do at least one [leetcode](https://leetcode.com/problemset/all/) algorithm problem every week
- review: read and comment on at least one English technical article (e.g. from [medium](https://medium.com)) every week
- tip: learn at least one technical skill, or  summarize some knowledge every week
- share: share a technical article which has ideas and thoughts

I will try my best to complete the weekly tasks starting from next week. BTW, today is 2019/3/24 sunday.


